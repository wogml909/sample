package Day01;

public class Test {

	//main
	public static void main(String[] args) {
		
		System.out.println("hi");
	}
	
}

