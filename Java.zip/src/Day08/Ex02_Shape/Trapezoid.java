package Day08.Ex02_Shape;

public class Trapezoid extends Shape {

	double width, height;

	@Override
	double area() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	double round() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}
