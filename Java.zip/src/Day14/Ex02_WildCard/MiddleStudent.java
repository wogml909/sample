package Day14.Ex02_WildCard;

public class MiddleStudent extends Student {

	public MiddleStudent(String name) {
		super(name);

	}

	@Override
	public String toString() {
		return "MiddleStudent ["+this.getName() + "]";
	}

}
