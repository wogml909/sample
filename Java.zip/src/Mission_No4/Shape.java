package Mission_No4;


//Shape2D 클래스 정의
public abstract class Shape {
//추상 메서드 draw()
	public abstract void draw();

//추상 메서드 resize()
	public abstract void resize();

//넓이를 반환하는 메서드 getArea()
	public abstract double getArea();
}

