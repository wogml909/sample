package _1000;

import java.util.Scanner;

public class _1050 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Scanner sc = new Scanner(System.in);
         int a  = sc.nextInt();
         int b  = sc.nextInt();
         
         if(a==b) {
        	 System.out.println(1);
         }else {
        	 System.out.println(0);
         }
	}

}
