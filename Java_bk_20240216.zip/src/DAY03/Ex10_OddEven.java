package DAY03;

public class Ex10_OddEven {

	public static void main(String[] args) {
		//1~20까지 정수중 홀수 짝수
		//홀수의 합계, 짝수의 합계를 구하여 출력하시오
		//1+3+5+7+9...=??  sum1
		//2+4+6+8+12...=?? sum2
		
		int a =0;
		int sum1  =0;
		int sum2  =0;
		
		while(a <= 20) {
			//홀수
			if(a % 2 == 1) {
				sum1 += a;
			}
			//짝수
		    if(a % 2 == 0) {
		    	sum2 += a;
		    }
		    a++;		
	}
	  System.out.println("홀수의 합계: " + sum1);
	  System.out.println("짝수의 합계: " + sum2);
 }
}