package Day09.Ex01_Computer;

public class MacBook extends LapTop {

	@Override
	public void typing() {
		System.out.println("MacBook - typing");
		
	}

}
