package Day10.Ex03_AnonymousObject;

//객체정의
public class Person {

	String name;
	String age;
	
	void work() {
		System.out.println("일을 합니다.");
	}
}
