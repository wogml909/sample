package _1100;

public class _1158 {

	public static void main(String[] args) {

//      1. 공이 30m~40m나 60m~70m에 들어오면 슬기가 이김
//		2. 그외 구간 체육선생이 이김
//		3.슬기가 던진 공의 위치가 입력으로 주어지면 슬기가 이긴 구간에는 win 출력 그외는 lose출력
	
	
	}

}
